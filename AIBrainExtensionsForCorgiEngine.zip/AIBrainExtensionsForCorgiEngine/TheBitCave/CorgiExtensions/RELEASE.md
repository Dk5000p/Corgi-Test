# AI Extensions for Corgi - Release

See [Release page](https://github.com/thebitcave/ai-brain-extensions-for-corgi-engine/releases)